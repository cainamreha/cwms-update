<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title><?php echo isset($_GET['paused']) ? "Wartungsarbeiten" : "Hier entsteht eine neue Webpräsenz"; ?> - <?php echo(isset($_SERVER['SERVER_NAME']) ? htmlspecialchars($_SERVER['SERVER_NAME']) : "") ?></title>
		<meta content="text/html; charset=utf-8" http-equiv="content-type">
		<meta name="robots" content="noindex,follow">
		<style>
		  body {
			font-family:verdana, arial, helvetica, sans-serif;
			font-size:0.75rem;
			color:#33499A;
			padding: 0;
			margin:0;
		  }
		  .banner {
			width:100%;
			height:270px;
			padding:3px 0;
			background: rgb(90,164,200);
			background: -moz-linear-gradient(top, rgba(90,164,200,1) 0%, rgba(51,140,183,1) 100%);
			background: -webkit-linear-gradient(top, rgba(90,164,200,1) 0%,rgba(51,140,183,1) 100%);
			background: linear-gradient(to bottom, rgba(90,164,200,1) 0%,rgba(51,140,183,1) 100%);
			filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#5aa4c8', endColorstr='#338cb7',GradientType=0 );
		  }
		</style>
	</head>	
	<body>
		<div style="width:100%; height:100%; position:relative;">
			<div style="text-align:center; height:100%; height:calc(100% - 225px); min-height:450px; padding:27px 0 360px; background:#FFFFFF;">
				<p><a href="http://www.hermani-webrealisierung.de"><img src="http://www.hermani-web.de/media/files/cwms/hermani-webrealisierung-logo-small.png" /></a></p>
				<div class="banner"><img alt="banner-01" src="http://www.hermani-webrealisierung.de/media/files/cwms/bluehexagons.jpg" style="height:270px; margin:0px auto 0;"></div>
				<p style="color: #2A5272; <?php echo isset($_GET['paused']) ? "font-size:16px;" : "font-size:22px;"; ?>  margin-top:36px; display:inline-block; width:auto; height:54px; line-height:54px; background:url('http://www.hermani-webrealisierung.de/media/files/cwms/service-ico.png') no-repeat 1.125rem -1px; padding:0 5.625rem; border-bottom: 1px solid #CFDBED; border-top: 1px solid #CFDBED;">
				<?php echo isset($_GET['paused']) ? "Die Website ist wegen Wartungsarbeiten vorübergehend nicht erreichbar." : "Hier entsteht eine neue Webpräsenz."; ?>
				</p>
				<?php if(isset($_GET['ban'])) echo "<p><br />Bitte laden Sie die Seite später erneut.<br />Sollten Sie vermehrt keinen Zugriff auf die Seite haben, informieren Sie bitte den Seitenbetreiber.</p>"; ?>
<?php
if(isset($_GET['paused'])) {
	$script	= $_SERVER['SCRIPT_NAME'];
	$page	= explode("/", $script);
	$dir	= next($page);
	$page	= $_SERVER['SERVER_NAME'] . ($dir != "access" ? '/' . $dir : '');
	
	echo '<p><a href="http://' . $page . '" style=" color: #2A5272;">' . $page . '</a></p>';
}
?>
			</div>
			<div style="position:relative;
						margin-top:-198px;
						background-color: #f5f4f0;
						background-image: url(http://server49.configcenter.info/bckg.gif);
						background-position: top right;
						background-repeat: no-repeat;
						width:100%;
						height:198px;">
				<table align="center" border="0" cellpadding="0" cellspacing="0" width="400">
					<tbody>
						<tr> 
							<td style="padding-top: 25px;" align="center" valign="top"><img src="http://server49.configcenter.info/loginscreen.gif" height="85" width="396"></td>
						</tr>
						<tr>
							<td style="padding-top: 50px;" align="center"><a href="http://www.swsoft.de/" title="Go to SWsoft homepage" target="_blank">
							<img src="http://server49.configcenter.info/swsoftpoweredby.gif" title="Go to SWsoft homepage" border="0" height="18" width="165"></a></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</body>
</html>