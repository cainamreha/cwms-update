<?php
// Crontab
$cronTab = true;

// cron.inc.php einbinden
require_once __DIR__ . "/../inc/cron.inc.php";
?>
