<?php
namespace Concise;


/**
* Class for 2 way encryption of data
*
*
*/
class myCrypt
{
    /**
    *
    * Constructor
    *
    * @access	public
    * @param	string    $key	myCrypt key, must be of valid size as from php 5.6 (key size use either 16, 24 or 32 byte keys for AES-128, 192 and 256 respectively)
    *
    */
    public function __construct($key = "cc-newmcrypt-key")
    {

		$this->key	= defined('CC_CRYPT_KEY') ? CC_CRYPT_KEY : $key;
		// NOTE: add padding to keep encoding results from mcrypt_encrypt(MCRYPT_RIJNDAEL_128...)
		if (strlen($this->key) % 16) {
		    $this->key = str_pad($this->key, strlen($this->key) + 16 - strlen($this->key) % 16, "\0");
		}
    }

    /**
    *
    * Encrypt a string
    *
    * @access	public
    * @param	string    $str
    * @return	string    The encrypted string
    *
    */
    public function encrypt($str)
    {
		// NOTE: add padding to keep encoding results from mcrypt_encrypt(MCRYPT_RIJNDAEL_128...)
		if (strlen($str) % 16) {
    		$str = str_pad($str, strlen($str) + 16 - strlen($str) % 16, "\0");
		}
        $str = openssl_encrypt($str, 'aes-128-ecb', $this->key, OPENSSL_RAW_DATA | OPENSSL_NO_PADDING);
        return $this->urlbase64_encode($str);
    }

    /**
    *
    * Decrypt a string
    *
    * @access   public
    * @param	string    $str
    * @return   string    The decrypted string
    *
    */
    public function decrypt($str)
    {
        $str = $this->urlbase64_decode($str);
        return openssl_decrypt($str, 'aes-128-ecb', $this->key, OPENSSL_RAW_DATA | OPENSSL_NO_PADDING);
    }


    /**
    *
    * Decrypt a string
    *
    * @access   public
    * @param	string    $str
    * @return   string    The decrypted string
    *
    */
	public function urlbase64_encode($str)
	{
		$data = base64_encode($str);
		$data = str_replace(array('+','/','='),array('-','_',''),$data);
		return $data;
	}


    /**
    *
    * Decrypt a string
    *
    * @access   public
    * @param	string    $str
    * @return   string    The decrypted string
    *
    */
	public function urlbase64_decode($str)
	{
		$data = str_replace(array('-','_'),array('+','/'),$str);
		$mod4 = strlen($data) % 4;

		if ($mod4) {
			$data .= substr('====', $mod4);
		}
		return base64_decode($data);
	}

} // end of class
