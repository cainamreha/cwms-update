<?php
namespace Concise;


################################################
################  SetStorage  ##################
################################################

// Set storage vars

class SetStorage extends Admin
{

	private $action				= "";
	private $cookieName			= "";
	private $cookieVal			= "";

	public function __construct($DB, $o_lng, $themeType)
	{

		// Admin-Elternklasse aufrufen
		parent::__construct($DB, $o_lng);

		// Theme-Setup
		$this->getThemeDefaults($themeType);

		if(isset($GLOBALS['_GET']['action']) && $GLOBALS['_GET']['action'] != "")
			$this->action = $GLOBALS['_GET']['action'];

	}

	public function conductAction()
	{

		// If generate thumbs
		if($this->action == "setcookie")
			return $this->generateThumbs();

		return true;

	} // Ende Methode conductAction



 	/**
	 * generateThumbs
	 *
	 * @access	public
	 */
	public function generateThumbs()
	{

		if(empty($GLOBALS['_GET']['cookie']))
			exit . die();

		$this->cookieName = urldecode($GLOBALS['_GET']['cookie']);

		if(isset($GLOBALS['_GET']['value']))
			$this->cookieVal = urldecode($GLOBALS['_GET']['value']);

		if($this->cookieVal != "") {
			$exp = time()+60*60*24*180;
		} else {
			$exp = time()-3600;
		}
		setcookie("conciseLogging_off", "true", $exp, "/", "", HTTPS_PROTOCOL, true);

		exit;
		die();

	}

} // end class EditElements
