<?php
namespace Concise;


###################################################
##################  setStorage  ###################
###################################################

// Set storage vars

// common.php einbinden
require_once "../../inc/common.php";
require_once "../inc/checkBackendAccess.inc.php"; // Berechtigung prüfen

require_once SYSTEM_DOC_ROOT . "/inc/adminclasses/class.SetStorage.php"; // SetStorage-Klasse

$themeType	= "admin";

// Object instanzieren
$o_listMedia	= new SetStorage($DB, $o_lng, $themeType);
$o_listMedia->conductAction();

exit;

?>
